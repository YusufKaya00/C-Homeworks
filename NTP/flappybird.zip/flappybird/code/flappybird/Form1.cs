using System.Media;
using System.Threading;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;
using Timer = System.Threading.Timer;

namespace FlappyBird
{
	public partial class Form1 : Form
	{
	

		int pipeSpeed = 8;
		int gravity = 15;
		int score = 0;
		bool gameOver = false;
		SoundPlayer flapSound; // Ses oynatmak i�in SoundPlayer nesnesi

		public Form1()
		{
			InitializeComponent();
			resetGame();
			flapSound = new SoundPlayer("flap.wav");
		
		}

		private void gameTimerEvent(object sender, EventArgs e)
		{
			pictureBird.Top += gravity;
			picturePipeDown.Left -= pipeSpeed;
			picturePipeUp.Left -= pipeSpeed;
			labelScore.Text = "Score: " + score;

			
			if (picturePipeDown.Left < -150)
			{
				picturePipeDown.Left = 800;
				
				score++; 
		

			}
			if (picturePipeUp.Left < -160)
			{
				picturePipeUp.Left = 800;
				 
				//score++;
			

			}

			
			if (pictureBird.Bounds.IntersectsWith(picturePipeDown.Bounds) ||
				pictureBird.Bounds.IntersectsWith(picturePipeUp.Bounds) ||
				pictureBird.Bounds.IntersectsWith(pictureGround.Bounds) ||
				pictureBird.Top < -25)
			{
				
				endGame(); // Oyun biter
			}

			
			if (score > 5)
			{
				pipeSpeed = 10;
			}
		}

		private void gameKeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Space && !gameOver) 
			{
				gravity = -15;
				flapSound.Play(); // Ses �al (Space'e bas�ld���nda)

			}
		}

		private void gameKeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Space && !gameOver) 
			{
				gravity = 15;
				
			}

			
			if (gameOver && e.KeyCode == Keys.Space)
			{
				resetGame();
			}
		}

		private void endGame()
		{
			gameTimer.Stop(); 
			labelScore.Text = "GAME OVER !!!"; 
			gameOver = true; 
		}

		private void resetGame()
		{
			pipeSpeed = 8;
			gravity = 15;
			score = 0;
			gameOver = false; 

			
			pictureBird.Top = 150;
			picturePipeDown.Left = 800;
			picturePipeUp.Left = 800;

			labelScore.Text = "Score: 0";
			gameTimer.Start(); 
		}
	}
}
