﻿namespace FlappyBird
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			pictureBird = new PictureBox();
			picturePipeDown = new PictureBox();
			picturePipeUp = new PictureBox();
			pictureGround = new PictureBox();
			labelScore = new Label();
			gameTimer = new System.Windows.Forms.Timer(components);
			animation = new System.Windows.Forms.Timer(components);
			((System.ComponentModel.ISupportInitialize)pictureBird).BeginInit();
			((System.ComponentModel.ISupportInitialize)picturePipeDown).BeginInit();
			((System.ComponentModel.ISupportInitialize)picturePipeUp).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureGround).BeginInit();
			SuspendLayout();
			// 
			// pictureBird
			// 
			pictureBird.Image = (Image)resources.GetObject("pictureBird.Image");
			pictureBird.Location = new Point(12, 145);
			pictureBird.Name = "pictureBird";
			pictureBird.Size = new Size(103, 75);
			pictureBird.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBird.TabIndex = 0;
			pictureBird.TabStop = false;
			// 
			// picturePipeDown
			// 
			picturePipeDown.Image = (Image)resources.GetObject("picturePipeDown.Image");
			picturePipeDown.Location = new Point(461, 399);
			picturePipeDown.Name = "picturePipeDown";
			picturePipeDown.Size = new Size(99, 170);
			picturePipeDown.SizeMode = PictureBoxSizeMode.StretchImage;
			picturePipeDown.TabIndex = 1;
			picturePipeDown.TabStop = false;
			// 
			// picturePipeUp
			// 
			picturePipeUp.Image = (Image)resources.GetObject("picturePipeUp.Image");
			picturePipeUp.Location = new Point(554, -2);
			picturePipeUp.Name = "picturePipeUp";
			picturePipeUp.Size = new Size(99, 133);
			picturePipeUp.SizeMode = PictureBoxSizeMode.StretchImage;
			picturePipeUp.TabIndex = 2;
			picturePipeUp.TabStop = false;
			// 
			// pictureGround
			// 
			pictureGround.Image = (Image)resources.GetObject("pictureGround.Image");
			pictureGround.Location = new Point(-3, 565);
			pictureGround.Name = "pictureGround";
			pictureGround.Size = new Size(746, 72);
			pictureGround.SizeMode = PictureBoxSizeMode.StretchImage;
			pictureGround.TabIndex = 3;
			pictureGround.TabStop = false;
			// 
			// labelScore
			// 
			labelScore.AutoSize = true;
			labelScore.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point);
			labelScore.Location = new Point(12, 9);
			labelScore.Name = "labelScore";
			labelScore.Size = new Size(173, 46);
			labelScore.TabIndex = 4;
			labelScore.Text = "SCORE : 0";
			// 
			// gameTimer
			// 
			gameTimer.Enabled = true;
			gameTimer.Interval = 20;
			gameTimer.Tick += gameTimerEvent;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			BackColor = Color.Cyan;
			ClientSize = new Size(743, 676);
			Controls.Add(pictureBird);
			Controls.Add(labelScore);
			Controls.Add(pictureGround);
			Controls.Add(picturePipeUp);
			Controls.Add(picturePipeDown);
			Name = "Form1";
			Text = "FlappyBird";
			KeyDown += gameKeyDown;
			KeyUp += gameKeyUp;
			((System.ComponentModel.ISupportInitialize)pictureBird).EndInit();
			((System.ComponentModel.ISupportInitialize)picturePipeDown).EndInit();
			((System.ComponentModel.ISupportInitialize)picturePipeUp).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureGround).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private PictureBox pictureBird;
		private PictureBox picturePipeDown;
		private PictureBox picturePipeUp;
		private PictureBox pictureGround;
		private Label labelScore;
		private System.Windows.Forms.Timer gameTimer;
		private System.Windows.Forms.Timer animation;
	}
}
